package mybeans;

import java.sql.*;
import mybeans.*;

public class BeanWithDrawAmount 
{
  private int amt;
  private int cnpt;
  private int an;
  
  public BeanWithDrawAmount()
  {
	  this.amt=0;
      this.cnpt=0; 
      this.an=0;
      
  }

  
public int getCnpt() {
	return cnpt;
}


public void setAn(int an) {
	this.an = an;
}

public void setAmt(int amt) {
	this.amt = amt;
	
	OnAmountChange();
}

  public void OnAmountChange()
  {
	   DbConnector db = new DbConnector();
	   db.getDbconnection();
	   
	   PreparedStatement pst;
	  

	   try
	   { 
	
	       pst=db.dbconnection.prepareStatement("update accounts set balance=balance-? where accno=? ; ");
	       pst.setInt(1,amt);
	       pst.setInt(2,an);

	       cnpt=pst.executeUpdate();
           

	       db.dbconnection.close(); 
	
           
           
	   }
	   catch(Exception e)
	   {
		   System.out.print(e);
	   }
	
	   
	   }
	
}

