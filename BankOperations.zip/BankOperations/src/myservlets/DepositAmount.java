package myservlets;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mybeans.BeanDepositAmount;
import mybeans.DbConnector;

/**
 * Servlet implementation class DepositAmount
 */
@WebServlet("/DepositAmount")
public class DepositAmount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DepositAmount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
PrintWriter out = response.getWriter();
		
		DbConnector db = new DbConnector();
		db.getDbconnection();
		
		int amt,acn,r,acc,yacn;
		
		
		amt=Integer.parseInt(request.getParameter("amt"));
		acn=Integer.parseInt(request.getParameter("accno"));
		
		BeanDepositAmount bt = new BeanDepositAmount();
		  bt.setAmt(amt);
		  bt.setAn(acn);
	   
		
		  bt.OnAmountChange ();
		  r=bt.getCnpt();
	     
			   if(r!=0)
			   {
				   out.print("<h4 style='color:green'>Amount transfer successful</h4");
				   out.print("<br>");
				   out.print("<br>");
				   out.print("<br>");
				   out.print("Amount is transfer to Acoount Number :-"+acn);
					 
			   }
			   else
			   {
				   out.print("Invalid Account Number");
				   out.print(" <br> ");
			       out.print(" or ");
			       out.print(" <br> ");
			       out.print("Amount is greter than 20000");
			   }   
			   
			   out.print("<br>");
			   out.print("<br>");
			   
			   out.print("<a href='Cashier.jsp'>Home</a>");
			


	}

}
