package mybeans;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;

public class ManagerTransferAmt 
{
   private String typ;
   private int no,re;
   private int amt,rlt;
   private int trno;
   
	
	public ManagerTransferAmt()
	{
		this.amt=0;
		this.no=0;
		this.re=0;
		this.typ="";
		this.trno=0;
		this.rlt=0;
		
	}

	public int getRe() {
		return re;
	}

	public void setTyp(String typ) {
		this.typ = typ;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	
	OnAmountTransfer();
	}
	
	public void OnAmountTransfer()
	{
		   DbConnector db = new DbConnector();
		   db.getDbconnection();
		   
		   
		   CallableStatement cst;
		   PreparedStatement pst;
		   try
		   {

		       cst= db.dbconnection.prepareCall("call trans(?,?,?) ; ");
		       cst.setInt(1,no);
		       cst.setString(2,typ);
		       cst.setInt(3,amt);

		      re= cst.executeUpdate();
		      
		      
		     
		      pst=db.dbconnection.prepareStatement("insert into acctransactions values(?,now(),?,?,?); ");
		      pst.setInt(1, trno);
		       pst.setInt(2,no);
		       pst.setString(3,typ);
		       pst.setInt(4,amt);
		  
		       rlt=pst.executeUpdate();
		            
		       db.dbconnection.close(); 
			       
		   }
		   catch(Exception e)
		   {
			   System.out.print(e);
		   }		   
	
}
}