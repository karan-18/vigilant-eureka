package mybeans;

import mybeans.DbConnector;
import java.sql.*;

public class NewRegisters 
{
  private 	String u,c,em,mo,p,g;
   private 	int a,id,id1;
   
   public NewRegisters() 
   {
	   this.id1= 0;
	   this.id= 0;
	    this.u="";
	    this.c="";
	    this.em="";
	    this.mo="";
	    this.p="";
	    this.g="";
	    this.a=0;
   }

public void setU(String u) {
	this.u = u;
	
}

public void setC(String c) {
	this.c = c;
	
}

public void setEm(String em) {
	this.em = em;
	
}

public void setMo(String mo) {
	this.mo = mo;
	
}

public void setP(String p) {
	this.p = p;
	
}

public void setG(String g) {
	this.g = g;

}

public void setId(int id) {
	this.id = id;
	}

public void setA(int a) {
	this.a = a;
	
	OnRegister();
}

   public int getId1() {
	return id1;
}

public void	OnRegister() 
   {
          PreparedStatement pst;
          DbConnector db = new DbConnector();
          db.getDbconnection();

          
try 
{
  
	pst=db.dbconnection.prepareStatement("insert into userpersonal values(?,now(),?,?,?,?,?,?) ;");
       pst.setInt(1,id);
       pst.setString(2,u);
       pst.setString(3,mo);
       pst.setString(4,g);
       pst.setString(5,em);
       pst.setString(6,c);
       pst.setInt(7,a);

       id1 = pst.executeUpdate();
        
        
        	
        
}
catch(Exception e)
{
	System.out.print(e);
}
}
}