package mybeans;
import java.sql.*;

public class DbConnector
{
	 public Connection dbconnection;
	  
	public DbConnector()
	{
	  try 
	  {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		   dbconnection=DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingdb?","root","volkswagen");
	   }   
	  catch(Exception e)
	  {
		  System.out.print(e);
	  }
 
}
	  public Connection getDbconnection()
	  {
			return dbconnection;	 
	  }
	
  
}
