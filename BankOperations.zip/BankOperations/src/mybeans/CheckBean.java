package mybeans;
import mybeans.DbConnector;
import java.sql.*;


public class CheckBean 
{
	private String uid;
	private String psw;
	private String uty;
	
	public CheckBean()
	{
		uid="";
		psw="";
		uty="";
	}

	public String getUty() {
		return uty;
	}

	public String getUid() {
		return uid;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}

	public void setPsw(String psw) {
		this.psw = psw;
	}

	public void OnUIDChange() {
	
		    PreparedStatement pst;
	        ResultSet rs;
	       
	        try {
	      	     
	        	DbConnector db = new DbConnector();
	            db.getDbconnection();
	        
	      		  
	              pst=db.dbconnection.prepareStatement("select userid,pswd,usertype from users where userid=? and pswd=?;");
	              pst.setString(1,uid);
	              pst.setString(2, psw);
	        
	             rs=pst.executeQuery();
	  
	             if(rs.next())
	          	   uty=rs.getString("usertype");
	                         	 
	             
	         db.dbconnection.close();             
	        }

	catch(Exception e)
	        {
	     System.out.print(e);
	}

	}
}