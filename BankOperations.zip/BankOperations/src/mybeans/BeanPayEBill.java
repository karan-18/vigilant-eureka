package mybeans;

import java.sql.*;
import mybeans.DbConnector;

public class BeanPayEBill 
{
	private int amt,acn,ctno;
	private String ct,st,bd,mo,u;
	private int cnpt;
	public BeanPayEBill()
	{
		this.amt=0;
		this.acn=0;
		this.ctno=0;
		 this.ct="";
		 this.st="";
		 this.bd="";
		 this.mo="";
		 this.u="";
		 this.cnpt=0;
		
	}

	public int getCnpt() {
		return cnpt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}

	public void setAcn(int acn) {
		this.acn = acn;
	}

	public void setCtno(int ctno) {
		this.ctno = ctno;
	}

	public void setCt(String ct) {
		this.ct = ct;
	}

	public void setSt(String st) {
		this.st = st;
	}

	public void setBd(String bd) {
		this.bd = bd;
	}

	public void setMo(String mo) {
		this.mo = mo;
	}

	public void setU(String u) {
		this.u = u;
		
		OnPayBill();
	}

	public void OnPayBill()
	{
		DbConnector db = new DbConnector();
		db.getDbconnection();
		
	    try
	    {
	    	PreparedStatement pst;
	    
		    pst=db.dbconnection.prepareStatement("insert into paybill values(?,?,?,?,?,?,?,now(),?) ; ");
		    pst.setInt(1,ctno); 
		    pst.setInt(2,acn);
	         pst.setString(3,u);
	         pst.setString(4,st);
	         pst.setString(5,ct);
	         pst.setString(6,bd);
	         pst.setInt(7,amt);
	         pst.setString(8,mo);
	         
	         cnpt=pst.executeUpdate();

	        db.dbconnection.close(); 
	}
	catch(Exception e)
	{
		   System.out.print(e);
	}	
	}
}
