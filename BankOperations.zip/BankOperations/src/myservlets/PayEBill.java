package myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mybeans.*;

/**
 * Servlet implementation class PayEBill
 */
@WebServlet("/PayEBill")
public class PayEBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PayEBill() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
     
		
		PrintWriter out = response.getWriter();
		
		DbConnector db = new DbConnector();
		db.getDbconnection();
		
		int amt,acn,cn;
		String ct,st,bd,mo,u;
		
		
		amt=Integer.parseInt(request.getParameter("amt"));
		acn=Integer.parseInt(request.getParameter("acn"));
		cn=Integer.parseInt(request.getParameter("cn"));
		ct=request.getParameter("city");
        st=request.getParameter("state");
        bd=request.getParameter("board");
        mo=request.getParameter("mob");
        u=request.getParameter("usr");
        
       BeanPayEBill bp = new BeanPayEBill();
       bp.setAcn(acn);
       bp.setAmt(amt);
        bp.setBd(bd);
        bp.setCtno(cn);
        bp.setMo(mo);
        bp.setSt(st);
        bp.setU(u);
        bp.setCt(ct);
        
        bp.OnPayBill();
        
        if(bp.getCnpt()!=0)
        {
        	out.print("<style type=\"text/css\">body{background-color:skyblue}</style>");
        	out.print("Bill payment is successful");
        }
        
        out.print("<br>");
        out.print("<br>");
        out.print("<a href='Customer.jsp'>Home</a>");
	
	}

}
