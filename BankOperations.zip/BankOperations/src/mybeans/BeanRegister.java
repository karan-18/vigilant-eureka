package mybeans;

import mybeans.DbConnector;
import java.sql.*;

public class BeanRegister 
{

	int id;
	int id1;
	
	public BeanRegister() 
	{
	   this.id=0;
	   this.id1=0;
	}

	public int getId1() {
		return id1;
	}

	public void setId(int id) {
		this.id = id;
		
		OnChangeID();
	}
	public void OnChangeID()
	{
		DbConnector db = new DbConnector();
		db.getDbconnection();
	
		PreparedStatement pst;
		ResultSet rs;
		try
		{
		   pst=db.dbconnection.prepareStatement("select accno from accounts where accno=?;");
		   pst.setInt(1, id);
		   rs=pst.executeQuery();
		
		if(rs.next())
		{
		   id1=rs.getInt("accno");
		}
		
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
	}
}
