package mybeans;


import java.sql.*;


public class CashierBeanTransAmounts 
{
	 private int amt,yacn;
	  private int cnpt;
	  private int an;
	  private int racc;
	  String typ;
	  
	  
	  public CashierBeanTransAmounts()
	  {
		  this.amt=0;
	      this.cnpt=0; 
	      this.an=0;
	       this.yacn=0;
	       this.racc=0;
	       this.typ="";
	  }


	public int getCnpt() {
		return cnpt;
	}
	public int getAn() {
		return an;
	}

	public int getRacc() {
		return racc;
	}


	public void setTyp(String typ) {
		this.typ = typ;
	}


	public void setYacn(int yacn) {
		this.yacn = yacn;
	}
	public void setAn(int an) {
		this.an = an;
	}

	public void setAmt(int amt) {
		this.amt = amt;
		
		OnAmountChange();
	}
	  public void OnAmountChange()
	  {
		   DbConnector db = new DbConnector();
		   db.getDbconnection();
		   
		   PreparedStatement pst,pst1;
		   ResultSet rs;

		   
		   try
		   {

			   pst=db.dbconnection.prepareStatement("select accno from accounts;");
				rs=pst.executeQuery();
				if(rs.next())
				{
			      racc=rs.getInt("accno");    		
				}
				
				pst1=db.dbconnection.prepareStatement("insert into acctrans values(?,?,now(),?); ");
			       pst1.setInt(1,an);
			       pst1.setString(2,typ);
			       pst1.setInt(3,amt);
			       
			       pst1.executeUpdate();
                
				if(amt<=20000)
				{
		         pst=db.dbconnection.prepareStatement("update accounts set balance=balance+? where accno=? ; ");
		       pst.setInt(1,amt);
		       pst.setInt(2,an);

		       cnpt=pst.executeUpdate();
	       
		       pst=db.dbconnection.prepareStatement("update accounts set balance=balance-? where accno=? ; ");
		       pst.setInt(1,amt);
		       pst.setInt(2,yacn);

		       pst.executeUpdate();
		       
		      }
		       
		       db.dbconnection.close(); 
			       
		   }
		   catch(Exception e)
		   {
			   System.out.print(e);
		   }
	
	   }
	
}

