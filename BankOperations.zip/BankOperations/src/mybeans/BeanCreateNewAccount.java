package mybeans;

import java.sql.PreparedStatement;

public class BeanCreateNewAccount
{
  private String accnm,accty;
  private int ano,cnpt;
  
  public BeanCreateNewAccount()
  {
	  
	  this.accnm="";
	  this.accty="";
	  this.ano=0;
	  this.cnpt=0;
  }

public void setAccnm(String accnm) {
	this.accnm = accnm;
	OnAccountFill();
}

public void setAccty(String accty) {
	this.accty = accty;
	OnAccountFill();
}


public void setAno(int ano) {
	this.ano = ano;

	OnAccountFill();
}

public int getCnpt() {
	return cnpt;
}



public void OnAccountFill()
{
	DbConnector db = new DbConnector();
	db.getDbconnection();
	
	try
	{
	PreparedStatement pst;
	
	pst=db.dbconnection.prepareStatement("insert into accounts(accno,accnm,acctype) values(?,?,?);");
	pst.setInt(1, ano);
	pst.setString(2,accnm);
	pst.setString(3, accty);
	
	cnpt=pst.executeUpdate();
	
	db.dbconnection.close();
	}
	catch(Exception e)
	{
		System.out.print(e);
	}
	}

}

