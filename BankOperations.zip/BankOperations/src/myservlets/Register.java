package myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mybeans.*;
/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out =response.getWriter();
		int id=Integer.parseInt(request.getParameter("uid"));
		
		DbConnector db= new DbConnector();
		db.getDbconnection();
		
		BeanRegister r = new BeanRegister();
		r.setId(id);

		 r.OnChangeID();
		 int re = r.getId1();
		 
		try {
        if(id==re)
        {  
        	out.print(id);
        	out.print("<br>");
        	out.print(re);
        	
        	out.print("'Welcome Sir!'  You are a member of our Branch.");
        	out.print("<br>");
        	out.print("Click here for a Registration Page.");
        	
        	out.print("<a href='Registration.jsp'> <u> register </u></a>");
        	}
        else
        {
        	out.print("You are not A customer of our branch. For Register you have to be account in our branch. Kindly create account to register.");
        	out.print("<br>");
        	out.print("<a href='index.jsp'> <u> HOME </u></a>");
       
        }
        db.dbconnection.close();
		}
		catch(Exception e)
		{
			out.print(e);
		}
	}

}
